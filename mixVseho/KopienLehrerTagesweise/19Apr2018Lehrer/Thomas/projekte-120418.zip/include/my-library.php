<?php
// echo 'Ich bin die Datei ' . __FILE__;

function testme() {
    return 'Ich bin testme';
}