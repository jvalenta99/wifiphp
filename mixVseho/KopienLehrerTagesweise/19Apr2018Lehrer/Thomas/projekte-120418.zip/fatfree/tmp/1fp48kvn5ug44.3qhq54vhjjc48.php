<?php echo $this->render('/views/navi.html',NULL,get_defined_vars(),0); ?>
<h2>Der Blog</h2>
<p>Hallo <?= ($user) ?></p>