<h2><?= ($title) ?></h2>
<?= ($this->raw($content)) ?>