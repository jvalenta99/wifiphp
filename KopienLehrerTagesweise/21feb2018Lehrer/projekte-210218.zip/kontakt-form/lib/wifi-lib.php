<?php

/**
 * Prüft, ob ein Formular geposted wurde
 *
 * @return boolean
 */
function isSent() {
    if ( count($_POST) > 0 ) {
        return true;
    }

    return false;

    // Kurzform: return count($_POST) > 0;
}

/**
 * Prüfen, ob ein Index $var in $_POST exisitiert
 *
 * @param [mixed] $var
 * @return bool
 */
function exists($var) {
    return array_key_exists($var, $_POST);
}

/**
 * Prüft, ob ein POST Feld ausgefüllt wurde
 *
 * @param [mixed] $var
 * @return bool
 */
function required($var) {
    /*
     Eine Bedingung kann als Rückgabewert gesetzt werden

     Eine Bedingung ist ein sog. Ausdruck. Ein Ausdruck wird zuerst ausgewertet, bevor
     das Ergebnis des Ausdrucks weiter verwendet wird.
     
     return exists($var) == false $_POST[$var] != '';
    */
    if ( exists($var) == true && $_POST[$var] != '' ) {
        return true;
    }

    return false;
}