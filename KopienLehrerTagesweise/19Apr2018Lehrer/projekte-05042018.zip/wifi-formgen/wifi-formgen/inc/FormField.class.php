<?php
/* 
    Diese Klasse existiert nur zu Testzwecken, sie 
    hat den selben Namen wie eine Klasse in FormLib.
    Die unterschiedlichen Namespaces machen eine Verwechslung
    unmöglich.
*/
namespace Other;
class FormField {
    public function render() {
        echo 'inc/FormField Class<br>';
    }
}