<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>mysqli Objekorientiert</title>
</head>
<body>
    <h1>mysqli Objekorientiert</h1>
    <?php
    // prozeduraler Stil
    //  $mysqli = mysqli_connect('localhost', 'root', '', 'classicmodels');
    // mysqli Objekt erstellen
    $mysqli = new mysqli('localhost', 'root', '', 'classicmodels');

    if ($mysqli->connect_errno !== 0) {
        die('Verbindungsfehler! ' .  $mysqli->connect_error);
    }

    $cid = 112; // kommt aus GET
    $sql = 'SELECT * FROM customers WHERE customerNumber = '. $cid ;
    
    // Das Resultat wird uns als Objekt zurückgegeben
    $res = $mysqli->query($sql);

    if ($res === false) {
        die('Fehler: ' . $mysqli->error);
    }

    echo '<ul>';    
    while($row = $res->fetch_assoc()) {
        echo "<li>{$row['customerName']}, {$row['contactFirstName']} {$row['contactLastName']} </li>";
    }
    echo '</ul>';


    ?>

    <h2>Prepared Statements</h2>
    <?php

    // Für Variablen, die unserem Statment übergeben werden, wird das ? als Platzhalter gesetzt 
    $sql = 'SELECT contactFirstName, contactLastName FROM customers WHERE customerNumber < ?';

    // Schritt 1 - Statement vorbereiten
    if (!$stmt = $mysqli->prepare($sql)) {
        die('Statement Fehler ' . $stmt->error);
    }

    // Schritt 2 - Paramenter binden
    $cid = '200'; // aus GET
    // über bind_param die Datentypen der Variablen bekannt machen.
    if (!$stmt->bind_param('i', $cid)) {
        die('Parameter Fehler ' . $stmt->error);
    }

    // Schritt 3 - ausführen
    if (!$stmt->execute()) {
        die('Execute Fehler ' . $stmt->error);
    }

    // Bei Select
    /* $res = $stmt->get_result();
    print_r($res);
    print_r($res->fetch_assoc()); */


    // auslesen mit bind_result
    $stmt->bind_result($fn, $ln);

    while($stmt->fetch()) {
        echo "<p>$fn $ln</p>";
    }
    ?>
</body>
</html>