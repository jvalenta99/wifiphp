<?php echo $this->render('/views/navi.html',NULL,get_defined_vars(),0); ?>

<h2><?= ($title) ?></h2>
<?= ($content) ?>