<?php echo $this->render('/views/page-header.html',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('/views/page-navi.html',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('/views/page-content.html',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('/views/page-footer.html',NULL,get_defined_vars(),0); ?>
