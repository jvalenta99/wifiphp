var indexSectionsWithContent =
{
  0: "$_cfgirst",
  1: "cfirst",
  2: "_cgirs",
  3: "$"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables"
};

