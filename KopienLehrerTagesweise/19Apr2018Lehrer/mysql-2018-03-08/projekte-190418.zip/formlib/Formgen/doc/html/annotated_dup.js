var annotated_dup =
[
    [ "Formgen", null, [
      [ "Checkbox", "class_formgen_1_1_checkbox.html", "class_formgen_1_1_checkbox" ],
      [ "Form", "class_formgen_1_1_form.html", "class_formgen_1_1_form" ],
      [ "Input", "class_formgen_1_1_input.html", "class_formgen_1_1_input" ],
      [ "Radio", "class_formgen_1_1_radio.html", "class_formgen_1_1_radio" ],
      [ "Reset", "class_formgen_1_1_reset.html", "class_formgen_1_1_reset" ],
      [ "Select", "class_formgen_1_1_select.html", "class_formgen_1_1_select" ],
      [ "Submit", "class_formgen_1_1_submit.html", "class_formgen_1_1_submit" ],
      [ "Textarea", "class_formgen_1_1_textarea.html", "class_formgen_1_1_textarea" ]
    ] ]
];