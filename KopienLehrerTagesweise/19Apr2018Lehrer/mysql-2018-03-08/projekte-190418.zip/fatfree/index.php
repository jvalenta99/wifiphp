<?php
    require_once('init.php');
?>
<pre>
<?php print_r($_SERVER); ?>
</pre>
