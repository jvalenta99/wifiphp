<nav>
    <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/shop">Shop</a></li>
        <li><a href="/blog">Blog</a></li>
        <li><a href="/impressum">Impressum</a></li>
    </ul>
</nav>