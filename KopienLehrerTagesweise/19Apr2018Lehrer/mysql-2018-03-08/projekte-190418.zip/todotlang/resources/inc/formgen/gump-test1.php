<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GUMP Übung</title>
</head>
<body>
<?php
    $data = [
        'vorname' => 'F3RR0R',
        'nachname' => '@Checker',
        'email' => ''
    ];

    /* 
        vorname: required, mindestens 6 Zeichen, max 30 Zeichen, alphabetisch
        nachname: required, mindestens 6 Zeichen, max 30 Zeichen, alphabetisch
        email: email Adresses
    */
?>
</body>
</html>