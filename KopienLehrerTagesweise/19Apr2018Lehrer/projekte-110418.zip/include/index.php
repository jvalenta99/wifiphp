<?php
// Eine Datei, in der nur PHP vorkommt, muss den PHP Tag nicht schließen

/* 
    include bindet eine PHP Datei an der angegebenen Stelle ein.
*/
include 'my-library.php';

require_once 'more-than-once.php';
require_once 'more-than-once.php';
require_once 'more-than-once.php';

/* 
    include liefert ein Warning, falls die Datei nicht existiert
    require einen fatal Error, bricht das Programm ab, falls Datei nicht existiert
    require_once bindet eine Datei nur beim ersten Aufruf ein, bricht das Programm ab, falls Datei nicht existiert
*/
/* include 'error.php';
require 'error.php'; */

echo '<br>Ich bin hier am Ende';